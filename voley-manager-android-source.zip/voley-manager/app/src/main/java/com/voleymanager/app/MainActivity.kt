package com.voleymanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.voleymanager.app.data.*
import kotlinx.coroutines.launch

private val Ink = Color(0xFF101B2D)
private val Panel = Color(0xFF192840)
private val Teal = Color(0xFF35D0B0)
private val Muted = Color(0xFF91A2B9)

class MainActivity : ComponentActivity() {
    private lateinit var db: VoleyDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = VoleyDatabase.get(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Teal, background = Ink, surface = Panel, onBackground = Color.White, onSurface = Color.White)) { VoleyApp(db) } }
    }
}

@Composable fun VoleyApp(db: VoleyDatabase) {
    var page by remember { mutableStateOf("Inicio") }
    var selectedTeam by remember { mutableStateOf<Long?>(null) }
    val teams by db.teamDao().observeAll().collectAsStateWithLifecycle(emptyList())
    val team = teams.firstOrNull { it.id == selectedTeam } ?: teams.firstOrNull()
    LaunchedEffect(team?.id) { if (selectedTeam == null && team != null) selectedTeam = team.id }
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel, contentColor = Color.White) {
            listOf("Inicio", "Equipos", "Jugadores", "Plan", "Más").forEach { item ->
                val icon = when(item) { "Inicio" -> Icons.Default.Home; "Equipos" -> Icons.Default.Groups; "Jugadores" -> Icons.Default.Person; "Plan" -> Icons.Default.CalendarMonth; else -> Icons.Default.Apps }
                NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Icon(icon, null) }, label = { Text(item, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Teal, selectedTextColor = Teal, indicatorColor = Teal.copy(alpha = .12f), unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VÓLEY MANAGER", color = Teal, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text(when(page) { "Inicio" -> "Tu equipo, bajo control"; "Equipos" -> "Mis equipos"; "Jugadores" -> "Plantel"; "Plan" -> "Planificación"; else -> "Herramientas" }, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(14.dp), color = Panel) { Icon(Icons.Default.SportsVolleyball, null, tint = Teal, modifier = Modifier.padding(12.dp).size(26.dp)) }
            }
            Spacer(Modifier.height(18.dp))
            if (team != null) TeamSelector(teams, team.id) { selectedTeam = it }
            Spacer(Modifier.height(16.dp))
            when(page) {
                "Inicio" -> HomePage(team, teams.size, db, onNavigate = { page = it })
                "Equipos" -> TeamsPage(teams, db) { selectedTeam = it }
                "Jugadores" -> if (team != null) PlayersPage(team, db) else EmptyState("Primero creá un equipo", "Agregá tu primer equipo para cargar el plantel.")
                "Plan" -> if (team != null) PlanPage(team, db) else EmptyState("Sin equipo seleccionado", "Creá un equipo para planificar entrenamientos.")
                else -> MorePage()
            }
        }
    }
}

@Composable fun TeamSelector(teams: List<Team>, selected: Long, onSelect: (Long)->Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Muted.copy(alpha=.35f))) {
            Icon(Icons.Default.Groups, null, tint = Teal, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(teams.firstOrNull { it.id == selected }?.name ?: "Seleccionar equipo"); Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ExpandMore, null)
        }
        DropdownMenu(expanded, { expanded = false }) { teams.forEach { DropdownMenuItem(text = { Text(it.name) }, onClick = { onSelect(it.id); expanded = false }) } }
    }
}

@Composable fun HomePage(team: Team?, teamCount: Int, db: VoleyDatabase, onNavigate: (String)->Unit) {
    val playerCount by (team?.let { db.playerDao().countForTeam(it.id) } ?: kotlinx.coroutines.flow.flowOf(0)).collectAsStateWithLifecycle(0)
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("PANEL DEL ENTRENADOR", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp)); Text(team?.name ?: "Bienvenido", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text(if(team != null) "${team.category} · Temporada ${team.season}" else "Comenzá creando tu primer equipo", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("EQUIPOS", teamCount.toString(), Modifier.weight(1f)); StatTile("JUGADORES", playerCount.toString(), Modifier.weight(1f)); StatTile("TEMPORADA", team?.season ?: "—", Modifier.weight(1f))
                }
            }
        }
        Text("Accesos rápidos", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickCard("Plantel", "Jugadores y posiciones", Icons.Default.Groups, Modifier.weight(1f)) { onNavigate("Jugadores") }
            QuickCard("Planificar", "Sesiones y objetivos", Icons.Default.CalendarMonth, Modifier.weight(1f)) { onNavigate("Plan") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickCard("Equipos", "Clubes y categorías", Icons.Default.EmojiEvents, Modifier.weight(1f)) { onNavigate("Equipos") }
            QuickCard("Herramientas", "Más funciones", Icons.Default.Dashboard, Modifier.weight(1f)) { onNavigate("Más") }
        }
        Surface(color = Teal.copy(alpha=.09f), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.TipsAndUpdates, null, tint = Teal); Spacer(Modifier.width(10.dp)); Text("Esta es la primera base funcional. Vamos a incorporar los módulos deportivos progresivamente.", color = Color(0xFFC8D5E5), fontSize = 12.sp) } }
    }
}

@Composable fun StatTile(label: String, value: String, modifier: Modifier = Modifier) { Surface(modifier, color = Color(0xFF223650), shape = RoundedCornerShape(12.dp)) { Column(Modifier.padding(10.dp)) { Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold); Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Teal) } } }
@Composable fun QuickCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: ()->Unit) { Surface(onClick = onClick, modifier = modifier.height(105.dp), color = Panel, shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) { Icon(icon, null, tint = Teal); Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 10.sp) } } } }

@Composable fun TeamsPage(teams: List<Team>, db: VoleyDatabase, onSelected: (Long)->Unit) {
    var show by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Equipos y categorías", modifier = Modifier.weight(1f), color = Muted, fontSize = 13.sp); Button(onClick = { show = true }, colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Ink)) { Icon(Icons.Default.Add, null); Text("Nuevo") } }
        if(teams.isEmpty()) EmptyState("Todavía no hay equipos", "Creá un equipo para empezar a organizar jugadores y entrenamientos.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(teams, key = { it.id }) { t -> Surface(onClick = { onSelected(t.id) }, color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(color = Teal.copy(alpha=.13f), shape = RoundedCornerShape(10.dp)) { Icon(Icons.Default.Groups, null, tint = Teal, modifier = Modifier.padding(10.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(t.name, fontWeight = FontWeight.Bold); Text("${t.category} · ${t.season}", color = Muted, fontSize = 12.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } } }
    }
    if(show) TeamDialog(onDismiss = { show = false }) { name, category, season -> db.teamDao().let { dao -> kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO) { dao.insert(Team(name=name, category=category, season=season)) } }; show = false }
}

@Composable fun TeamDialog(onDismiss: ()->Unit, onSave: (String,String,String)->Unit) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Mayores") }; var season by remember { mutableStateOf("2026") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Nuevo equipo")}, text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(name,{name=it},label={Text("Nombre del equipo")},singleLine=true); OutlinedTextField(category,{category=it},label={Text("Categoría")},singleLine=true); OutlinedTextField(season,{season=it},label={Text("Temporada")},singleLine=true) } }, confirmButton={TextButton(onClick={ if(name.isNotBlank()) onSave(name,category,season) }, enabled=name.isNotBlank()){Text("Crear")}}, dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})
}

@Composable fun PlayersPage(team: Team, db: VoleyDatabase) {
    val players by db.playerDao().observeForTeam(team.id).collectAsStateWithLifecycle(emptyList())
    var show by remember { mutableStateOf(false) }
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("${players.size} integrantes", color=Muted, fontSize=13.sp); Text("Plantel de ${team.name}", fontWeight=FontWeight.Bold) }; Button(onClick={show=true}, colors=ButtonDefaults.buttonColors(containerColor=Teal,contentColor=Ink)){Icon(Icons.Default.PersonAdd,null);Text("Agregar")} }
        if(players.isEmpty()) EmptyState("Plantel vacío", "Agregá jugadores con número, posición y datos básicos.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(players,key={it.id}) { p -> Surface(color=Panel,shape=RoundedCornerShape(13.dp),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically) { Surface(color=Teal.copy(alpha=.14f),shape=RoundedCornerShape(10.dp)) { Text(p.number.toString(),color=Teal,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=13.dp,vertical=10.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position}${if(p.heightCm>0) " · ${p.heightCm} cm" else ""}",color=Muted,fontSize=12.sp)}; IconButton(onClick={ kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO){db.playerDao().delete(p)} }){Icon(Icons.Default.DeleteOutline,null,tint=Muted)} } } } }
    }
    if(show) PlayerDialog(onDismiss={show=false}) { name,number,pos,height -> kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO){db.playerDao().insert(Player(teamId=team.id,name=name,number=number,position=pos,heightCm=height))}; show=false }
}

@Composable fun PlayerDialog(onDismiss:()->Unit,onSave:(String,Int,String,Int)->Unit){var name by remember{mutableStateOf("")};var number by remember{mutableStateOf("1")};var pos by remember{mutableStateOf("Punta")};var height by remember{mutableStateOf("")}; AlertDialog(onDismissRequest=onDismiss,title={Text("Agregar jugador")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(name,{name=it},label={Text("Nombre y apellido")},singleLine=true);OutlinedTextField(number,{number=it},label={Text("Número de camiseta")},singleLine=true);OutlinedTextField(pos,{pos=it},label={Text("Posición")},singleLine=true);OutlinedTextField(height,{height=it},label={Text("Altura en cm (opcional)")},singleLine=true)}},confirmButton={TextButton(onClick={if(name.isNotBlank())onSave(name,number.toIntOrNull()?:0,pos,height.toIntOrNull()?:0)},enabled=name.isNotBlank()){Text("Guardar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})}

@Composable fun PlanPage(team: Team, db: VoleyDatabase) {
    val sessions by db.sessionDao().observeForTeam(team.id).collectAsStateWithLifecycle(emptyList())
    var show by remember{mutableStateOf(false)}
    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Sesiones de entrenamiento",fontWeight=FontWeight.Bold);Text("Plan de ${team.name}",color=Muted,fontSize=12.sp)};Button(onClick={show=true},colors=ButtonDefaults.buttonColors(containerColor=Teal,contentColor=Ink)){Icon(Icons.Default.Add,null);Text("Nueva")}}
        Surface(color=Panel,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(15.dp)){Text("ESTRUCTURA DE PLANIFICACIÓN",color=Teal,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp);Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Macrociclo","Mesociclo","Microciclo","Sesión").forEachIndexed{index,label->Surface(color=Color(0xFF263C56),shape=RoundedCornerShape(8.dp),modifier=Modifier.weight(1f)){Column(Modifier.padding(8.dp)){Text("0${index+1}",color=Teal,fontSize=10.sp);Text(label,fontSize=10.sp,fontWeight=FontWeight.SemiBold)}}}}}}
        if(sessions.isEmpty()) EmptyState("Todavía no hay sesiones", "Creá entrenamientos y después vamos a sumar objetivos, cargas, contenidos y ejercicios.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(sessions,key={it.id}){s->Surface(color=Panel,shape=RoundedCornerShape(13.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(s.title,fontWeight=FontWeight.Bold);Text("${s.date} · ${s.durationMin} minutos",color=Teal,fontSize=12.sp);if(s.objective.isNotBlank())Text(s.objective,color=Muted,fontSize=12.sp)}}}}
    }
    if(show) SessionDialog(onDismiss={show=false}){title,date,obj,duration->kotlinx.coroutines.GlobalScope.launch(kotlinx.coroutines.Dispatchers.IO){db.sessionDao().insert(TrainingSession(teamId=team.id,title=title,date=date,objective=obj,durationMin=duration))};show=false}
}
@Composable fun SessionDialog(onDismiss:()->Unit,onSave:(String,String,String,Int)->Unit){var title by remember{mutableStateOf("")};var date by remember{mutableStateOf("2026-11-06")};var obj by remember{mutableStateOf("")};var duration by remember{mutableStateOf("90")};AlertDialog(onDismissRequest=onDismiss,title={Text("Nueva sesión")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Nombre")});OutlinedTextField(date,{date=it},label={Text("Fecha (AAAA-MM-DD)")});OutlinedTextField(obj,{obj=it},label={Text("Objetivo")});OutlinedTextField(duration,{duration=it},label={Text("Duración en minutos")})}},confirmButton={TextButton(onClick={if(title.isNotBlank())onSave(title,date,obj,duration.toIntOrNull()?:90)},enabled=title.isNotBlank()){Text("Guardar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})}

@Composable fun MorePage(){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){listOf("Biblioteca de ejercicios" to "Colección reutilizable de tareas", "Pizarra táctica" to "Diseñá sistemas y movimientos", "Estadísticas" to "Seguimiento técnico y por partido", "Asistencias" to "Control de entrenamientos", "Informes" to "Exportación y reportes").forEach{(a,b)->Surface(color=Panel,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.SportsVolleyball,null,tint=Teal);Spacer(Modifier.width(12.dp));Column{Text(a,fontWeight=FontWeight.Bold);Text(b,color=Muted,fontSize=12.sp)};Spacer(Modifier.weight(1f));Text("PRÓXIMO",color=Teal,fontSize=9.sp,fontWeight=FontWeight.Bold)}}}}}
@Composable fun EmptyState(title:String,subtitle:String){Surface(color=Panel.copy(alpha=.7f),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inbox,null,tint=Teal,modifier=Modifier.size(32.dp));Spacer(Modifier.height(8.dp));Text(title,fontWeight=FontWeight.Bold);Text(subtitle,color=Muted,fontSize=12.sp);}}}
