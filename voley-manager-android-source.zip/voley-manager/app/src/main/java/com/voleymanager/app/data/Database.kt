package com.voleymanager.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "teams")
data class Team(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val category: String, val season: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "players", foreignKeys = [ForeignKey(entity = Team::class, parentColumns = ["id"], childColumns = ["teamId"], onDelete = ForeignKey.CASCADE)], indices = [Index("teamId")])
data class Player(@PrimaryKey(autoGenerate = true) val id: Long = 0, val teamId: Long, val name: String, val number: Int, val position: String, val heightCm: Int = 0, val notes: String = "")

@Entity(tableName = "sessions", foreignKeys = [ForeignKey(entity = Team::class, parentColumns = ["id"], childColumns = ["teamId"], onDelete = ForeignKey.CASCADE)], indices = [Index("teamId")])
data class TrainingSession(@PrimaryKey(autoGenerate = true) val id: Long = 0, val teamId: Long, val title: String, val date: String, val objective: String = "", val durationMin: Int = 90)

@Dao interface TeamDao {
    @Query("SELECT * FROM teams ORDER BY createdAt DESC") fun observeAll(): Flow<List<Team>>
    @Insert suspend fun insert(team: Team): Long
    @Delete suspend fun delete(team: Team)
}
@Dao interface PlayerDao {
    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY number, name") fun observeForTeam(teamId: Long): Flow<List<Player>>
    @Query("SELECT COUNT(*) FROM players WHERE teamId = :teamId") fun countForTeam(teamId: Long): Flow<Int>
    @Insert suspend fun insert(player: Player)
    @Delete suspend fun delete(player: Player)
}
@Dao interface SessionDao {
    @Query("SELECT * FROM sessions WHERE teamId = :teamId ORDER BY date DESC") fun observeForTeam(teamId: Long): Flow<List<TrainingSession>>
    @Insert suspend fun insert(session: TrainingSession)
}

@Database(entities = [Team::class, Player::class, TrainingSession::class], version = 1, exportSchema = true)
abstract class VoleyDatabase : RoomDatabase() {
    abstract fun teamDao(): TeamDao
    abstract fun playerDao(): PlayerDao
    abstract fun sessionDao(): SessionDao
    companion object {
        @Volatile private var INSTANCE: VoleyDatabase? = null
        fun get(context: Context): VoleyDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, VoleyDatabase::class.java, "voley_manager.db").build().also { INSTANCE = it }
        }
    }
}
