# Vóley Manager — Android MVP 0.1.0

Proyecto Android nativo en Kotlin + Jetpack Compose + Room. La primera entrega implementa navegación, creación/selección de equipos, alta/baja de jugadores y creación de sesiones de entrenamiento con persistencia local offline.

## Compilar APK

Requisitos: JDK 17, Android SDK 35 y Gradle 8.9.

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

También incluye GitHub Actions (`.github/workflows/android.yml`) para compilar la APK en la nube al subir el proyecto a un repositorio GitHub y ejecutar el workflow.

## Estado y alcance

Esta es una base inicial funcional, no la aplicación completa. Aún faltan edición avanzada, sincronización multiusuario/nube, permisos, planificación jerárquica completa, pizarra, biblioteca, estadísticas, asistencias y exportaciones. La base de datos local usa Room y no requiere cuenta ni servicio externo.
